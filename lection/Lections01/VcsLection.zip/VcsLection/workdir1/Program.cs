Console.WriteLine("hello");

void PrintInfo(string text)
	=> Console.WriteLine(text.txt);